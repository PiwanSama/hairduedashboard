@auth()
    @include('layouts.navbars.navs.auth')
@endauth
